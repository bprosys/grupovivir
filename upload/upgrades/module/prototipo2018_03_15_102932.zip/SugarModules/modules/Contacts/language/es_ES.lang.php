<?php 
 // created: 2018-03-15 10:28:56
$mod_strings['LBL_IDENTIFICACION'] = 'Cédula o RUC';
$mod_strings['LBL_LEAD_SOURCE'] = 'Como se enteró de nosotros:';
$mod_strings['LBL_DESCRIPTION'] = 'Observaciones:';
$mod_strings['LBL_RELEACION_PRINCIPAL'] = 'Relación con el Principal';
$mod_strings['LBL_DETAILVIEW_PANEL1'] = 'Nuevo';
$mod_strings['LBL_DIRECT_REPORTS_SUBPANEL_TITLE'] = 'Informadores Directos';

?>
