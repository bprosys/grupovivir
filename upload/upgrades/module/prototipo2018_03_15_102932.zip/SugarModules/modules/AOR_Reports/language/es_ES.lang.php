<?php 
 // created: 2018-03-15 10:28:47
$mod_strings['LBL_CONTRATO_CATEGORIAPRODUCTO_AOS_PRODUCT_CATEGORIES_ID'] = 'contrato categoriaproducto (relacionado Producto - Categorías ID)';
$mod_strings['LBL_CONTRATO_CATEGORIAPRODUCTO'] = 'contrato categoriaproducto';

?>
