<?php 
 // created: 2018-03-15 10:29:01
$mod_strings['LBL_IDENTIFICACION'] = 'Cédula o RUC';

?>
