<?php 
 // created: 2018-03-15 10:28:47
$mod_strings['LBL_CODIGO_CATEGORIA'] = 'Código de Categoría';
$mod_strings['LBL_SUB_CATEGORIES'] = 'Sub categorías';
$mod_strings['LBL_EDITVIEW_PANEL1'] = 'Nuevo Panel 1';
$mod_strings['LBL_EDITVIEW_PANEL2'] = 'Nuevo Panel 2';
$mod_strings['LBL_EDITVIEW_PANEL3'] = 'Nuevo Panel 3';
$mod_strings['LNK_NEW_RECORD'] = 'Crear Categorías de Producto';
$mod_strings['LNK_LIST'] = 'Ver Categorías de Producto';
$mod_strings['LBL_LIST_FORM_TITLE'] = 'Lista de Categorías de Producto';
$mod_strings['LBL_SEARCH_FORM_TITLE'] = 'Buscar Categorías de Producto';
$mod_strings['LBL_PRODUCT_CATEGORYS_NAME'] = 'Categoría Padre';
$mod_strings['LBL_PARENT_CATEGORY'] = 'Categoría Padre';
$mod_strings['LBL_HOMEPAGE_TITLE'] = 'Mis Categorías de Producto';
$mod_strings['LBL_AOS_PRODUCT_CATEGORIES_AOS_PRODUCTS_FROM_AOS_PRODUCTS_TITLE'] = 'Categorías de producto: Producto a partir del nombre del producto';
$mod_strings['AOS_Products'] = 'Productos';

?>
