<?php
$viewdefs ['Cases'] = 
array (
  'QuickCreate' => 
  array (
    'templateMeta' => 
    array (
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
      'useTabs' => false,
      'tabDefs' => 
      array (
        'DEFAULT' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
      ),
    ),
    'panels' => 
    array (
      'default' => 
      array (
        0 => 
        array (
          0 => 'name',
          1 => 'priority',
        ),
        1 => 
        array (
          0 => 'status',
          1 => 'account_name',
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'nombre_banco_c',
            'label' => 'LBL_NOMBRE_BANCO',
          ),
          1 => 
          array (
            'name' => 'nombre_tramitador_c',
            'label' => 'LBL_NOMBRE_TRAMITADOR',
          ),
        ),
        3 => 
        array (
          0 => 
          array (
            'name' => 'casos_categoriaproducto_c',
            'studio' => 'visible',
            'label' => 'LBL_CASOS_CATEGORIAPRODUCTO',
          ),
          1 => '',
        ),
        4 => 
        array (
          0 => 'assigned_user_name',
        ),
        5 => 
        array (
          0 => 'description',
        ),
      ),
    ),
  ),
);
$viewdefs['Cases']['QuickCreate']['templateMeta'] = array (
  'maxColumns' => '2',
  'widths' => 
  array (
    0 => 
    array (
      'label' => '10',
      'field' => '30',
    ),
    1 => 
    array (
      'label' => '10',
      'field' => '30',
    ),
  ),
);
?>
