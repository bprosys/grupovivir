<?php 
 // created: 2018-03-15 10:28:54
$mod_strings['LBL_NOMBRE_BANCO'] = 'Banco';
$mod_strings['LBL_NOMBRE_TRAMITADOR'] = 'Nombre del Tramitador';
$mod_strings['LBL_CASOS_CATEGORIAPRODUCTO_AOS_PRODUCT_CATEGORIES_ID'] = 'Categoria Producto (relacionado Producto - Categorías ID)';
$mod_strings['LBL_CASOS_CATEGORIAPRODUCTO'] = 'Categoria Producto';

?>
