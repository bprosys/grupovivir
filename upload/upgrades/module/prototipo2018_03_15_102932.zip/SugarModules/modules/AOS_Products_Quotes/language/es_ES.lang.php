<?php 
 // created: 2018-03-15 10:28:47
$mod_strings['LBL_AOS_PRODUCTS'] = 'Producto';

?>
