<?php 
 // created: 2018-03-15 10:28:47
$mod_strings['LBL_EDITVIEW_PANEL1'] = 'Nuevo Panel 1';
$mod_strings['LBL_AOS_PRODUCT_CATEGORYS_NAME'] = 'Categoría de Producto';
$mod_strings['LBL_AOS_PRODUCT_CATEGORIES'] = 'Categorías de Producto';
$mod_strings['LNK_NEW_RECORD'] = 'Crear Producto';
$mod_strings['LNK_LIST'] = 'Productos';
$mod_strings['LBL_LIST_FORM_TITLE'] = 'Lista de Producto';
$mod_strings['LBL_SEARCH_FORM_TITLE'] = 'Buscar Producto';
$mod_strings['LBL_HOMEPAGE_TITLE'] = 'Mis Productos';
$mod_strings['LBL_ESTADO'] = 'Estado';
$mod_strings['LBL_METRAJE'] = 'Metraje';
$mod_strings['LBL_FECHA_RESERVA'] = 'Fecha Reserva';

?>
