<?php 
 // created: 2018-03-15 10:29:06
$mod_strings['LBL_PROYECTO_CATEGORIAPRODUCTO_AOS_PRODUCT_CATEGORIES_ID'] = 'Categoría Producto (relacionado Producto - Categorías ID)';
$mod_strings['LBL_PROYECTO_CATEGORIAPRODUCTO'] = 'Categoría Producto';

?>
