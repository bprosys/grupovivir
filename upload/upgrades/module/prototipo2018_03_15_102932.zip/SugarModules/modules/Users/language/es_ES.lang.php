<?php 
 // created: 2018-03-15 10:29:11
$mod_strings['LBL_IDENTIFICACION'] = 'Cédula o RUC';

?>
