<?php 
 // created: 2018-03-15 10:28:46
$mod_strings['LBL_EDITVIEW_PANEL1'] = 'Nuevo Panel 1';

?>
