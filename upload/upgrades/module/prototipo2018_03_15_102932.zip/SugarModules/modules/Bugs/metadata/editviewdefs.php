<?php
$viewdefs ['Bugs'] = 
array (
  'EditView' => 
  array (
    'templateMeta' => 
    array (
      'form' => 
      array (
        'hidden' => 
        array (
          0 => '<input type="hidden" name="account_id" value="{$smarty.request.account_id}">',
          1 => '<input type="hidden" name="contact_id" value="{$smarty.request.contact_id}">',
        ),
      ),
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
      'useTabs' => false,
      'tabDefs' => 
      array (
        'LBL_BUG_INFORMATION' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
        'LBL_PANEL_ASSIGNMENT' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
      ),
    ),
    'panels' => 
    array (
      'lbl_bug_information' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'bug_number',
            'type' => 'readonly',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'name',
            'displayParams' => 
            array (
              'size' => 60,
              'required' => true,
            ),
          ),
          1 => 'priority',
        ),
        2 => 
        array (
          0 => 'status',
          1 => 'type',
        ),
        3 => 
        array (
          0 => 
          array (
            'name' => 'incidencias_cuentas_c',
            'studio' => 'visible',
            'label' => 'LBL_INCIDENCIAS_CUENTAS',
          ),
          1 => 
          array (
            'name' => 'incidencia_contacto_c',
            'studio' => 'visible',
            'label' => 'LBL_INCIDENCIA_CONTACTO',
          ),
        ),
        4 => 
        array (
          0 => 
          array (
            'name' => 'incidencia_categoriaproducto_c',
            'studio' => 'visible',
            'label' => 'LBL_INCIDENCIA_CATEGORIAPRODUCTO',
          ),
          1 => 
          array (
            'name' => 'incidencia_numerodeparte_c',
            'studio' => 'visible',
            'label' => 'LBL_INCIDENCIA_NUMERODEPARTE',
          ),
        ),
        5 => 
        array (
          0 => '',
          1 => '',
        ),
        6 => 
        array (
          0 => '',
          1 => '',
        ),
        7 => 
        array (
          0 => 
          array (
            'name' => 'description',
            'nl2br' => true,
          ),
        ),
        8 => 
        array (
          0 => 
          array (
            'name' => 'work_log',
            'nl2br' => true,
          ),
        ),
      ),
      'LBL_PANEL_ASSIGNMENT' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'assigned_user_name',
            'label' => 'LBL_ASSIGNED_TO_NAME',
          ),
        ),
      ),
    ),
  ),
);
$viewdefs['Bugs']['EditView']['templateMeta'] = array (
  'form' => 
  array (
    'hidden' => 
    array (
      0 => '<input type="hidden" name="account_id" value="{$smarty.request.account_id}">',
      1 => '<input type="hidden" name="contact_id" value="{$smarty.request.contact_id}">',
    ),
  ),
  'maxColumns' => '2',
  'widths' => 
  array (
    0 => 
    array (
      'label' => '10',
      'field' => '30',
    ),
    1 => 
    array (
      'label' => '10',
      'field' => '30',
    ),
  ),
);
?>
