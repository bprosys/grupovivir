<?php
$viewdefs ['Bugs'] = 
array (
  'QuickCreate' => 
  array (
    'templateMeta' => 
    array (
      'form' => 
      array (
        'hidden' => 
        array (
          0 => '<input type="hidden" name="account_id" value="{$smarty.request.account_id}">',
          1 => '<input type="hidden" name="contact_id" value="{$smarty.request.contact_id}">',
        ),
      ),
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
      'useTabs' => false,
      'tabDefs' => 
      array (
        'DEFAULT' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
      ),
    ),
    'panels' => 
    array (
      'DEFAULT' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'priority',
          ),
          1 => 
          array (
            'name' => 'assigned_user_name',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'source',
          ),
          1 => 
          array (
            'name' => 'team_name',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'type',
          ),
          1 => 
          array (
            'name' => 'status',
          ),
        ),
        3 => 
        array (
          0 => 
          array (
            'name' => 'incidencias_cuentas_c',
            'studio' => 'visible',
            'label' => 'LBL_INCIDENCIAS_CUENTAS',
          ),
          1 => 
          array (
            'name' => 'incidencia_contacto_c',
            'studio' => 'visible',
            'label' => 'LBL_INCIDENCIA_CONTACTO',
          ),
        ),
        4 => 
        array (
          0 => 
          array (
            'name' => 'incidencia_categoriaproducto_c',
            'studio' => 'visible',
            'label' => 'LBL_INCIDENCIA_CATEGORIAPRODUCTO',
          ),
          1 => 
          array (
            'name' => 'incidencia_numerodeparte_c',
            'studio' => 'visible',
            'label' => 'LBL_INCIDENCIA_NUMERODEPARTE',
          ),
        ),
        5 => 
        array (
          0 => 
          array (
            'name' => 'name',
            'displayParams' => 
            array (
              'required' => true,
            ),
          ),
        ),
        6 => 
        array (
          0 => 
          array (
            'name' => 'description',
          ),
        ),
      ),
    ),
  ),
);
$viewdefs['Bugs']['QuickCreate']['templateMeta'] = array (
  'form' => 
  array (
    'hidden' => 
    array (
      0 => '<input type="hidden" name="account_id" value="{$smarty.request.account_id}">',
      1 => '<input type="hidden" name="contact_id" value="{$smarty.request.contact_id}">',
    ),
  ),
  'maxColumns' => '2',
  'widths' => 
  array (
    0 => 
    array (
      'label' => '10',
      'field' => '30',
    ),
    1 => 
    array (
      'label' => '10',
      'field' => '30',
    ),
  ),
);
?>
