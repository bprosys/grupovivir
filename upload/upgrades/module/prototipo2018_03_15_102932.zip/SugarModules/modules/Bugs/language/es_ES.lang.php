<?php 
 // created: 2018-03-15 10:28:51
$mod_strings['LBL_TYPE'] = 'Tipo:';
$mod_strings['LBL_INCIDENCIAS_CUENTAS_ACCOUNT_ID'] = 'Cuentas (relacionado Cuenta ID)';
$mod_strings['LBL_INCIDENCIAS_CUENTAS'] = 'Cuentas';
$mod_strings['LBL_INCIDENCIA_CATEGORIAPRODUCTO_AOS_PRODUCT_CATEGORIES_ID'] = ' Categoría Producto (relacionado Producto - Categorías ID)';
$mod_strings['LBL_INCIDENCIA_CATEGORIAPRODUCTO'] = ' Categoría Producto';
$mod_strings['LBL_INCIDENCIA_NUMERODEPARTE_AOS_PRODUCTS_ID'] = 'Numero de Parte (relacionado Producto ID)';
$mod_strings['LBL_INCIDENCIA_NUMERODEPARTE'] = 'Producto';
$mod_strings['LBL_INCIDENCIA_CONTACTO_CONTACT_ID'] = 'incidencia contacto (relacionado Contacto ID)';
$mod_strings['LBL_INCIDENCIA_CONTACTO'] = 'Contacto';

?>
