<?php 
 // created: 2018-03-15 10:29:04
$mod_strings['LBL_LEAD_SOURCE'] = 'Como se enteró de éste proyecto:';
$mod_strings['LBL_SALES_STAGE'] = 'Etapa de ventas:';
$mod_strings['LBL_CODIGO_CATEGORIA'] = 'Categoria';

?>
