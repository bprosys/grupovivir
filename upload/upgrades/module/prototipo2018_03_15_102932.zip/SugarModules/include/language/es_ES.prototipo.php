<?php 
$app_list_strings['contract_status_list'] = array (
  'Not Started' => 'Por Firmar',
  'In Progress' => 'Firmado',
  'Signed' => 'Cerrado (Retirados)',
  'CerradoCompleto' => 'Cerrado (Completo)',
);$app_list_strings['producto_estatus_list'] = array (
  'Disponible' => 'Disponible',
  'Reservado' => 'Reservado',
  'Vendido' => 'Vendido',
);$app_list_strings['bug_type_dom'] = array (
  'Defect' => 'Excepciones',
  'Feature' => 'Garantia',
);$app_list_strings['sales_stage_dom'] = array (
  'Prospecting' => 'Prospecto',
  'Qualification' => 'Calificación',
  'Needs Analysis' => 'Necesita Análisis',
  'Value Proposition' => 'Propuesta de Valor',
  'Id. Decision Makers' => 'Identificar a los tomadores de decisión',
  'Perception Analysis' => 'Análisis de Percepción',
  'Proposal/Price Quote' => 'Propuesta/Presupuesto',
  'Negotiation/Review' => 'Negociación/Revisión',
  'Closed Won' => 'Ganado',
  'Closed Lost' => 'Perdido',
  'Retirados' => 'Retirados',
);