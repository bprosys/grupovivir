<?php 
$app_list_strings['contract_status_list'] = array (
  'Not Started' => 'Not Started',
  'In Progress' => 'In Progress',
  'Signed' => 'Signed',
  'CerradoCompleto' => 'Cerrado (Completo)',
);$app_list_strings['producto_estatus_list'] = array (
  'Disponible' => 'Disponible',
  'Reservado' => 'Reservado',
  'Vendido' => 'Vendido',
);$app_list_strings['bug_type_dom'] = array (
  'Defect' => 'Defect',
  'Feature' => 'Feature',
);$app_list_strings['sales_stage_dom'] = array (
  'Prospecting' => 'Prospecting',
  'Qualification' => 'Qualification',
  'Needs Analysis' => 'Needs Analysis',
  'Value Proposition' => 'Value Proposition',
  'Id. Decision Makers' => 'Identifying Decision Makers',
  'Perception Analysis' => 'Perception Analysis',
  'Proposal/Price Quote' => 'Proposal/Price Quote',
  'Negotiation/Review' => 'Negotiation/Review',
  'Closed Won' => 'Closed Won',
  'Closed Lost' => 'Closed Lost',
  'Retirados' => 'Retirados',
);