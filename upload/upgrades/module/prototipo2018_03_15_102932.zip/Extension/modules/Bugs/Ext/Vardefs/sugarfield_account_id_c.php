<?php
 // created: 2017-11-23 03:49:06
$dictionary['Bug']['fields']['account_id_c']['inline_edit']=1;

 ?>