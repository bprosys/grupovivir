<?php
 // created: 2017-11-23 03:47:20
$dictionary['Bug']['fields']['type']['len']=100;
$dictionary['Bug']['fields']['type']['inline_edit']=true;
$dictionary['Bug']['fields']['type']['comments']='The type of issue (ex: issue, feature)';
$dictionary['Bug']['fields']['type']['merge_filter']='disabled';

 ?>