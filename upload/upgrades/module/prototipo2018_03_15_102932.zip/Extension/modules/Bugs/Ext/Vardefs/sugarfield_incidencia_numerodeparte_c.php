<?php
 // created: 2017-11-23 04:21:07
$dictionary['Bug']['fields']['incidencia_numerodeparte_c']['inline_edit']='1';
$dictionary['Bug']['fields']['incidencia_numerodeparte_c']['labelValue']='Producto';

 ?>