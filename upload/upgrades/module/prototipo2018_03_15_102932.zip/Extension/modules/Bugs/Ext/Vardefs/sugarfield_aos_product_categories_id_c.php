<?php
 // created: 2017-11-23 04:04:50
$dictionary['Bug']['fields']['aos_product_categories_id_c']['inline_edit']=1;

 ?>