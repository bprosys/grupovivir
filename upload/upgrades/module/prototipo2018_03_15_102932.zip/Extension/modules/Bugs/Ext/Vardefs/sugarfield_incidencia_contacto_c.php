<?php
 // created: 2017-11-23 04:25:53
$dictionary['Bug']['fields']['incidencia_contacto_c']['inline_edit']='1';
$dictionary['Bug']['fields']['incidencia_contacto_c']['labelValue']='Contacto';

 ?>