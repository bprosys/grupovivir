<?php
 // created: 2017-11-23 04:25:00
$dictionary['Bug']['fields']['contact_id_c']['inline_edit']=1;

 ?>