<?php
 // created: 2017-11-23 03:49:06
$dictionary['Bug']['fields']['incidencias_cuentas_c']['inline_edit']='1';
$dictionary['Bug']['fields']['incidencias_cuentas_c']['labelValue']='Cuentas';

 ?>