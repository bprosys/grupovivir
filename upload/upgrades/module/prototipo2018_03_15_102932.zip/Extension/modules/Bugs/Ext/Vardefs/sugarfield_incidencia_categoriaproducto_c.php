<?php
 // created: 2017-11-23 04:04:50
$dictionary['Bug']['fields']['incidencia_categoriaproducto_c']['inline_edit']='1';
$dictionary['Bug']['fields']['incidencia_categoriaproducto_c']['labelValue']=' Categoría Producto';

 ?>