<?php
 // created: 2017-11-23 04:16:01
$dictionary['Bug']['fields']['aos_products_id_c']['inline_edit']=1;

 ?>