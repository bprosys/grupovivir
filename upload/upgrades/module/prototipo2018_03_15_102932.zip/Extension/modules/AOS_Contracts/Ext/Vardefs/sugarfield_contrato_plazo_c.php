<?php
 // created: 2017-11-24 04:27:54
$dictionary['AOS_Contracts']['fields']['contrato_plazo_c']['inline_edit']='1';
$dictionary['AOS_Contracts']['fields']['contrato_plazo_c']['labelValue']='Plazo (Meses)';

 ?>