<?php
 // created: 2017-11-23 03:14:22
$dictionary['AOS_Contracts']['fields']['status']['inline_edit']=true;
$dictionary['AOS_Contracts']['fields']['status']['merge_filter']='disabled';

 ?>