<?php
 // created: 2017-11-23 03:17:05
$dictionary['AOS_Contracts']['fields']['monto_cuota_c']['inline_edit']='1';
$dictionary['AOS_Contracts']['fields']['monto_cuota_c']['labelValue']='Monto Cuota';

 ?>