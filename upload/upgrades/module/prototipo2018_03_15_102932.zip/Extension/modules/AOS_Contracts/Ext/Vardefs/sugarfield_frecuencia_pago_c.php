<?php
 // created: 2017-11-23 03:22:46
$dictionary['AOS_Contracts']['fields']['frecuencia_pago_c']['inline_edit']='1';
$dictionary['AOS_Contracts']['fields']['frecuencia_pago_c']['labelValue']='Frecuencia de Pago';

 ?>