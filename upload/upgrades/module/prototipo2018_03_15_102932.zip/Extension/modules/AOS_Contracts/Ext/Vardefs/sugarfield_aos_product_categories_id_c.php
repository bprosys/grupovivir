<?php
 // created: 2017-11-24 04:12:27
$dictionary['AOS_Contracts']['fields']['aos_product_categories_id_c']['inline_edit']=1;

 ?>