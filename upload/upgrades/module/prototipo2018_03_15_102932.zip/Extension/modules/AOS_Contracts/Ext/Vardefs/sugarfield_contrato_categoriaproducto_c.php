<?php
 // created: 2017-11-24 04:12:27
$dictionary['AOS_Contracts']['fields']['contrato_categoriaproducto_c']['inline_edit']='1';
$dictionary['AOS_Contracts']['fields']['contrato_categoriaproducto_c']['labelValue']='Categoria Producto';

 ?>