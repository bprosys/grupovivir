<?php
// created: 2017-12-14 23:04:14
$dictionary["Account"]["fields"]["notes_accounts_1"] = array (
  'name' => 'notes_accounts_1',
  'type' => 'link',
  'relationship' => 'notes_accounts_1',
  'source' => 'non-db',
  'module' => 'Notes',
  'bean_name' => 'Note',
  'vname' => 'LBL_NOTES_ACCOUNTS_1_FROM_NOTES_TITLE',
);
