<?php
 // created: 2017-11-18 18:01:51
$dictionary['User']['fields']['identificacion_c']['inline_edit']='1';
$dictionary['User']['fields']['identificacion_c']['labelValue']='Cédula o RUC';

 ?>