<?php
 // created: 2017-11-21 17:09:19
$dictionary['Contact']['fields']['releacion_principal_c']['inline_edit']='1';
$dictionary['Contact']['fields']['releacion_principal_c']['labelValue']='Relación con el Principal';

 ?>