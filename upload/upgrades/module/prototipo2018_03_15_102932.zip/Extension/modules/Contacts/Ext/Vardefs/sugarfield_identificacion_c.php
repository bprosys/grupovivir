<?php
 // created: 2017-11-18 18:11:29
$dictionary['Contact']['fields']['identificacion_c']['inline_edit']='1';
$dictionary['Contact']['fields']['identificacion_c']['labelValue']='Cédula o RUC';

 ?>