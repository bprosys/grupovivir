<?php
 // created: 2017-11-18 15:03:47
$dictionary['AOS_Product_Categories']['fields']['codigo_categoria_c']['inline_edit']='1';
$dictionary['AOS_Product_Categories']['fields']['codigo_categoria_c']['labelValue']='Código de Categoría';

 ?>