<?php
//auto-generated file DO NOT EDIT
$layout_defs['AOS_Product_Categories']['subpanel_setup']['aos_products']['override_subpanel_name'] = 'AOS_Product_Categories_subpanel_aos_products';
?>