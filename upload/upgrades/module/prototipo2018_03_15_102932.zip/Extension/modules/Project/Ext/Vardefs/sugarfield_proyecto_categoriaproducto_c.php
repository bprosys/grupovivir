<?php
 // created: 2017-11-23 16:30:33
$dictionary['Project']['fields']['proyecto_categoriaproducto_c']['inline_edit']='1';
$dictionary['Project']['fields']['proyecto_categoriaproducto_c']['labelValue']='Categoría Producto';

 ?>