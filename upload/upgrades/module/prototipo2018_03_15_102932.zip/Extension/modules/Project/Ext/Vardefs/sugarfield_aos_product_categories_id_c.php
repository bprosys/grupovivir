<?php
 // created: 2017-11-23 16:30:33
$dictionary['Project']['fields']['aos_product_categories_id_c']['inline_edit']=1;

 ?>