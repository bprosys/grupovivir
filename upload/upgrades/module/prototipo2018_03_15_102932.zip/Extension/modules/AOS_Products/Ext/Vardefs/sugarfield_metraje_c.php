<?php
 // created: 2017-11-18 17:20:54
$dictionary['AOS_Products']['fields']['metraje_c']['inline_edit']='1';
$dictionary['AOS_Products']['fields']['metraje_c']['labelValue']='Metraje';

 ?>