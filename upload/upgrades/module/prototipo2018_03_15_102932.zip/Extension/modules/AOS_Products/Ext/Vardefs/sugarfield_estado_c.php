<?php
 // created: 2017-11-18 20:36:29
$dictionary['AOS_Products']['fields']['estado_c']['inline_edit']='1';
$dictionary['AOS_Products']['fields']['estado_c']['labelValue']='Estado';

 ?>