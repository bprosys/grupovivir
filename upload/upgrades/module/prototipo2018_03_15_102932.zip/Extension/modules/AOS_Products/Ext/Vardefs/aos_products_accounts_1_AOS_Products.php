<?php
// created: 2017-11-22 01:41:09
$dictionary["AOS_Products"]["fields"]["aos_products_accounts_1"] = array (
  'name' => 'aos_products_accounts_1',
  'type' => 'link',
  'relationship' => 'aos_products_accounts_1',
  'source' => 'non-db',
  'module' => 'Accounts',
  'bean_name' => 'Account',
  'vname' => 'LBL_AOS_PRODUCTS_ACCOUNTS_1_FROM_ACCOUNTS_TITLE',
  'id_name' => 'aos_products_accounts_1accounts_idb',
);
$dictionary["AOS_Products"]["fields"]["aos_products_accounts_1_name"] = array (
  'name' => 'aos_products_accounts_1_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_AOS_PRODUCTS_ACCOUNTS_1_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'aos_products_accounts_1accounts_idb',
  'link' => 'aos_products_accounts_1',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
$dictionary["AOS_Products"]["fields"]["aos_products_accounts_1accounts_idb"] = array (
  'name' => 'aos_products_accounts_1accounts_idb',
  'type' => 'link',
  'relationship' => 'aos_products_accounts_1',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'left',
  'vname' => 'LBL_AOS_PRODUCTS_ACCOUNTS_1_FROM_ACCOUNTS_TITLE',
);
