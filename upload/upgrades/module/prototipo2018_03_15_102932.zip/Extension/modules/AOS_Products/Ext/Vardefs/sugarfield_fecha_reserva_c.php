<?php
 // created: 2017-11-21 17:24:34
$dictionary['AOS_Products']['fields']['fecha_reserva_c']['inline_edit']='1';
$dictionary['AOS_Products']['fields']['fecha_reserva_c']['options']='date_range_search_dom';
$dictionary['AOS_Products']['fields']['fecha_reserva_c']['labelValue']='Fecha Reserva';
$dictionary['AOS_Products']['fields']['fecha_reserva_c']['enable_range_search']='1';

 ?>