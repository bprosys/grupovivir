<?php
 // created: 2017-11-18 19:30:12
$dictionary['AOS_Quotes']['fields']['approval_status']['inline_edit']=true;
$dictionary['AOS_Quotes']['fields']['approval_status']['merge_filter']='disabled';

 ?>