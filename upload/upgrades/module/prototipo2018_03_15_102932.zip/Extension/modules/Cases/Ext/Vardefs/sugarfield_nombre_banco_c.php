<?php
 // created: 2017-11-23 04:46:57
$dictionary['Case']['fields']['nombre_banco_c']['inline_edit']='1';
$dictionary['Case']['fields']['nombre_banco_c']['labelValue']='Banco';

 ?>