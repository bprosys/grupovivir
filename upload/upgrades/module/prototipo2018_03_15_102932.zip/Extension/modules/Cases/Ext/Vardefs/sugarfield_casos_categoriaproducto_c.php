<?php
 // created: 2017-11-23 04:48:35
$dictionary['Case']['fields']['casos_categoriaproducto_c']['inline_edit']='1';
$dictionary['Case']['fields']['casos_categoriaproducto_c']['labelValue']='Categoria Producto';

 ?>