<?php
 // created: 2017-11-23 04:47:33
$dictionary['Case']['fields']['nombre_tramitador_c']['inline_edit']='1';
$dictionary['Case']['fields']['nombre_tramitador_c']['labelValue']='Nombre del Tramitador';

 ?>