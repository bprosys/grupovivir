<?php
 // created: 2017-11-22 18:08:45
$dictionary['Opportunity']['fields']['codigo_categoria_c']['inline_edit']='1';
$dictionary['Opportunity']['fields']['codigo_categoria_c']['labelValue']='Categoria';

 ?>