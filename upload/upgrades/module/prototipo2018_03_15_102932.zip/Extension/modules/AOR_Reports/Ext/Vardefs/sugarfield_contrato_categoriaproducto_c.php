<?php
 // created: 2017-11-24 04:07:14
$dictionary['AOR_Report']['fields']['contrato_categoriaproducto_c']['inline_edit']='1';
$dictionary['AOR_Report']['fields']['contrato_categoriaproducto_c']['labelValue']='contrato categoriaproducto';

 ?>