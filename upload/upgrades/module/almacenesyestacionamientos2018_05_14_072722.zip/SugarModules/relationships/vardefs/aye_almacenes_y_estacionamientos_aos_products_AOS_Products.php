<?php
// created: 2018-05-14 07:27:22
$dictionary["AOS_Products"]["fields"]["aye_almacenes_y_estacionamientos_aos_products"] = array (
  'name' => 'aye_almacenes_y_estacionamientos_aos_products',
  'type' => 'link',
  'relationship' => 'aye_almacenes_y_estacionamientos_aos_products',
  'source' => 'non-db',
  'module' => 'AYE_almacenes_y_estacionamientos',
  'bean_name' => false,
  'side' => 'right',
  'vname' => 'LBL_AYE_ALMACENES_Y_ESTACIONAMIENTOS_AOS_PRODUCTS_FROM_AYE_ALMACENES_Y_ESTACIONAMIENTOS_TITLE',
);
