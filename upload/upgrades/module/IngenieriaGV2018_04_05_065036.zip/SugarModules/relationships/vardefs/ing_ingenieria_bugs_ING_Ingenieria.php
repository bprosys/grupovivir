<?php
// created: 2018-04-05 06:50:36
$dictionary["ING_Ingenieria"]["fields"]["ing_ingenieria_bugs"] = array (
  'name' => 'ing_ingenieria_bugs',
  'type' => 'link',
  'relationship' => 'ing_ingenieria_bugs',
  'source' => 'non-db',
  'module' => 'Bugs',
  'bean_name' => 'Bug',
  'side' => 'right',
  'vname' => 'LBL_ING_INGENIERIA_BUGS_FROM_BUGS_TITLE',
);
